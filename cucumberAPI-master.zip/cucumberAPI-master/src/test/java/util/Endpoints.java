package util;

public class Endpoints {
    public static final String USERENDPOINT = "users";
    public static final String POSTENDPOINT = "posts";
    public static final String COMMENTENDPOINT = "comments";
    public static final String TODOENDPOINT = "todos";

}
