package Models;

import lombok.Getter;

@Getter
public class ErrorObject {

    private String field;
    private String message;
}
